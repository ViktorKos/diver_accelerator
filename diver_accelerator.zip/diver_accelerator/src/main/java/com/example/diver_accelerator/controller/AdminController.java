package com.example.diver_accelerator.controller;

import com.example.diver_accelerator.entity.Diver;
import com.example.diver_accelerator.entity.Role;
import com.example.diver_accelerator.entity.User;
import com.example.diver_accelerator.service.DiverService;
import com.example.diver_accelerator.service.RoleService;
import com.example.diver_accelerator.service.UserService;
import com.example.diver_accelerator.transientClasses.Sort;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/admin")
public class AdminController {
    @Autowired
    private UserService userService;
    @Autowired
    private RoleService roleService;
    @Autowired
    protected DiverService diverService;
    protected Sort sort = new Sort();
    //diver
    //read_diver
    @RequestMapping(value = "/divers/{sort_num}", method = RequestMethod.GET)
    public ModelAndView allPatientsPage(@PathVariable("sort_num") int sort_num) {

        List<Diver> divers = diverService.allDivers();

        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("diversList", divers);
        modelAndView.setViewName("admin/tables/divers");
        return modelAndView;
    }
    //ToDo ------------------------------------------------------------//
    //create_diver
    @GetMapping("/add_diver")
    public ModelAndView addPageDiver(@ModelAttribute("message") String message) {
        ModelAndView modelAndView = new ModelAndView();

        if (message.equals("y")) {
            modelAndView.addObject("message", message);
        } else {
            modelAndView.addObject("message", null);
        }

        modelAndView.addObject("diver", new Diver());
        modelAndView.addObject("diver", diverService.allDivers());
        modelAndView.setViewName("admin/forms/form_divers");
        return modelAndView;
    }

//----------------------------------------------------------------------------------------------------//

    //role
    //read_role
    @RequestMapping(value = "/role/{sort_num}", method = RequestMethod.GET)
    public ModelAndView allRolePage(@PathVariable("sort_num") int sort_num) {

        List<Role> roles = roleService.allRole();
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("roleList",roles);
        modelAndView.setViewName("admin/tables/role");
        return modelAndView;
    }
   //create_role
    @RequestMapping(value = "/add_role", method = RequestMethod.GET)
    public ModelAndView addPageRole(@ModelAttribute("message") String message) {
        Role role = new Role();

        ModelAndView modelAndView = new ModelAndView();
        if (message.equals("y")) {
            modelAndView.addObject("message", message);
        } else {
            modelAndView.addObject("message", null);
        }
        modelAndView.addObject("role", role);
        modelAndView.setViewName("admin/forms/form_role");
        return modelAndView;
    }

    @RequestMapping(value = "/add_role", method = RequestMethod.POST)
    public ModelAndView addRole(@ModelAttribute("role") Role role,
                                @ModelAttribute("name") String s_name) {
        ModelAndView modelAndView = new ModelAndView();
        role.setName("ROLE_" + s_name);

        if (roleService.checkId(role.getId())) {
            roleService.add(role);
            modelAndView.setViewName("redirect:/admin/role/1");
        } else {
            modelAndView.addObject("message", "y");
            modelAndView.setViewName("redirect:/admin/add_role");
        }

        return modelAndView;
    }

    @RequestMapping(value = "/{id}/edit_role", method = RequestMethod.GET)
    public ModelAndView editPageRole(@PathVariable("id") int id) {
        Role role = roleService.getById(id);

        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("admin/forms/form_role");
        modelAndView.addObject("role", role);
        return modelAndView;
    }
    //update_role
    @RequestMapping(value = "/add_role", method = RequestMethod.POST, params = "edit")
    public ModelAndView editRole(@ModelAttribute("role") Role role) {
        roleService.add(role);

        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("redirect:/admin/role/1");
        return modelAndView;
    }
    //delete_role
    @RequestMapping(value = "/{id}/delete_role", method = RequestMethod.GET)
    public ModelAndView deleteRole(@PathVariable("id") int id) {
        Role role = roleService.getById(id);
        roleService.delete(role);

        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("redirect:/admin/role/1");

        return modelAndView;
    }
    //---------------------------CRUD USER-------------------------------------------------//
    //Read USER
    //user
    //user
    @RequestMapping(value = "/user/{sort_num}", method = RequestMethod.GET)
    public ModelAndView allUserPage(@PathVariable("sort_num") int sort_num) {
        List<User> userList = userService.allUsers();

        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("userList", sort.sortUser(userList, sort_num));
        modelAndView.setViewName("admin/tables/user");
        return modelAndView;
    }


    @GetMapping("/add_user")
    public ModelAndView addPageUser(@ModelAttribute("message") String message) {
        ModelAndView modelAndView = new ModelAndView();

        if (message.equals("y")) {
            modelAndView.addObject("message", message);
        } else {
            modelAndView.addObject("message", null);
        }

        modelAndView.addObject("user", new User());
        modelAndView.addObject("roles", roleService.allRole());
        modelAndView.setViewName("admin/forms/form_user");

        return modelAndView;
    }

    @PostMapping("/add_user")
    public ModelAndView addUser(@ModelAttribute("user") @Valid User user,
                                @ModelAttribute("selected_role") int role_id) throws NoSuchAlgorithmException {
        user.setId(SecureRandom.getInstance("SHA1PRNG").nextInt() + "_" + user.getUsername());
        user.setSelected(false);

        ModelAndView modelAndView = new ModelAndView();

        if (!userService.saveUser(user, role_id)) {
            modelAndView.addObject("message", "y");
            modelAndView.setViewName("redirect:/admin/add_user");
        } else {
            modelAndView.setViewName("redirect:/admin/user/1");
        }

        return modelAndView;
    }


    @RequestMapping(value = "/change_password/{id}", method = RequestMethod.GET)
    public ModelAndView editPageUserPassword(@PathVariable("id") String id) {
        User user = userService.findUserById(id);
        Optional<Role> role = user.getRoles().stream().findFirst();

        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("admin/forms/form_user_password");
        modelAndView.addObject("user", user);
        modelAndView.addObject("my_role_id", role.orElse(new Role()).getId());

        return modelAndView;
    }

    @RequestMapping(value = "/change_password", method = RequestMethod.POST, params = "edit")
    public ModelAndView editUserPassword(@ModelAttribute("user") @Valid User user,
                                         @ModelAttribute("my_role_id") int my_role_id) {
        userService.editUserPassword(user, my_role_id);

        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("redirect:/admin/" + user.getUsername() + "/edit_user");
        return modelAndView;
    }

    @RequestMapping(value = "/{username}/edit_user", method = RequestMethod.GET)
    public ModelAndView editPageUser(@PathVariable("username") String username) {
        User user = (User) userService.loadUserByUsername(username);
        Optional<Role> role = user.getRoles().stream().findFirst();

        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("admin/forms/form_user");
        modelAndView.addObject("user", user);
        modelAndView.addObject("roles", roleService.allRole());
        modelAndView.addObject("my_role", role.orElse(new Role()));

        return modelAndView;
    }

    @RequestMapping(value = "/add_user", method = RequestMethod.POST, params = "edit")
    public ModelAndView editUser(@ModelAttribute("user") @Valid User user,
                                 @ModelAttribute("selected_role") int role_id) {

        userService.editUser(user, role_id);

        Optional<Role> role = user.getRoles().stream().findFirst();

        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("redirect:/admin/user/1");

        return modelAndView;
    }

    @RequestMapping(value = "/{id}/delete_user", method = RequestMethod.GET)
    public ModelAndView deleteUser(@PathVariable("id") String id) {
        userService.deleteUser(id);

        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("redirect:/admin/user/1");

        return modelAndView;
    }
}
