package com.example.diver_accelerator.transientClasses;

import com.example.diver_accelerator.entity.User;
import lombok.NoArgsConstructor;

import java.util.Comparator;
import java.util.List;

@NoArgsConstructor
public class Sort {

    public List<User> sortUser(List<User> users, int i) {
        switch (i) {
            case 1: {
                users.sort(Comparator.comparing(User::getUsername));
                break;
            }
            case 2: {
                users.sort(Comparator.comparing(User::isSelected));
                break;
            }

        }

        return users;
    }


}
