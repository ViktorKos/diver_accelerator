package com.example.diver_accelerator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiverAcceleratorApplication {

    public static void main(String[] args) {
        SpringApplication.run(DiverAcceleratorApplication.class, args);
    }

}
