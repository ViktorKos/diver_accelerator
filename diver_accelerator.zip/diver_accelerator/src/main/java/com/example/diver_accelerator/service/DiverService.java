package com.example.diver_accelerator.service;

import com.example.diver_accelerator.entity.Diver;
import com.example.diver_accelerator.entity.Role;
import com.example.diver_accelerator.repository.DiverRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
public class DiverService {

    @Autowired
    private DiverRepository diverRepository;

    public List<Diver> allDivers() { return diverRepository.findAll();
    }
    @Transactional
    public void add(Diver diver) {
        diverRepository.save(diver);
    }
}
