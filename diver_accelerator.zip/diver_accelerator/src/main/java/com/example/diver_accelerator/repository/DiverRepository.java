package com.example.diver_accelerator.repository;

import com.example.diver_accelerator.entity.Diver;
import com.example.diver_accelerator.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DiverRepository extends JpaRepository<Diver, Long> {

}
